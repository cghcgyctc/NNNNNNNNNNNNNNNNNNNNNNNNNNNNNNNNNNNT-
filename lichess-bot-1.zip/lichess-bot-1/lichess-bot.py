"""Starting point for lichess-bot."""
from lib.lichess_bot import start_program

if __name__ == "__main__":
    start_program()

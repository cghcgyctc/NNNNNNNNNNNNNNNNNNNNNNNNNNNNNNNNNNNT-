import os
import subprocess
import threading
from bottle import Bottle, request, response, redirect, template, static_file, TEMPLATE_PATH
import json

app = Bottle()

ADMIN_USERNAME = "44"
ADMIN_PASSWORD = "88877aA"

sessions = {}
bot_process = None
bot_running = False
bot_log = []

def get_session():
    session_id = request.get_cookie("session_id")
    if session_id and session_id in sessions:
        return sessions[session_id]
    return {}

def set_session(data):
    import uuid
    session_id = request.get_cookie("session_id")
    if not session_id:
        session_id = str(uuid.uuid4())
        response.set_cookie("session_id", session_id, path="/")
    sessions[session_id] = data
    return session_id

def run_bot():
    global bot_process, bot_running, bot_log
    bot_log = []
    try:
        bot_process = subprocess.Popen(
            ["python", "lichess-bot.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1
        )
        bot_running = True
        for line in bot_process.stdout:
            bot_log.append(line.strip())
            if len(bot_log) > 100:
                bot_log.pop(0)
        bot_running = False
    except Exception as e:
        bot_log.append(f"Error: {str(e)}")
        bot_running = False

LOGIN_HTML = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ورود ادمین - Lichess Bot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); min-height: 100vh; display: flex; justify-content: center; align-items: center; }
        .login-container { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border-radius: 20px; padding: 40px; width: 380px; box-shadow: 0 25px 45px rgba(0, 0, 0, 0.2); border: 1px solid rgba(255, 255, 255, 0.1); }
        .logo { text-align: center; margin-bottom: 30px; }
        .logo h1 { color: #fff; font-size: 28px; margin-bottom: 10px; }
        .logo p { color: rgba(255, 255, 255, 0.7); font-size: 14px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; color: rgba(255, 255, 255, 0.8); margin-bottom: 8px; font-size: 14px; }
        .form-group input { width: 100%; padding: 15px; border: none; border-radius: 10px; background: rgba(255, 255, 255, 0.1); color: #fff; font-size: 16px; outline: none; transition: all 0.3s; }
        .form-group input:focus { background: rgba(255, 255, 255, 0.2); box-shadow: 0 0 20px rgba(79, 172, 254, 0.3); }
        .form-group input::placeholder { color: rgba(255, 255, 255, 0.5); }
        .btn { width: 100%; padding: 15px; border: none; border-radius: 10px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(102, 126, 234, 0.4); }
        .error { background: rgba(255, 82, 82, 0.2); color: #ff5252; padding: 10px; border-radius: 8px; margin-bottom: 20px; text-align: center; font-size: 14px; }
        .chess-icon { font-size: 50px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">
            <div class="chess-icon">♞</div>
            <h1>Lichess Bot</h1>
            <p>پنل مدیریت ربات شطرنج</p>
        </div>
        {{error}}
        <form method="POST">
            <div class="form-group">
                <label>نام کاربری</label>
                <input type="text" name="username" placeholder="نام کاربری را وارد کنید" required>
            </div>
            <div class="form-group">
                <label>رمز عبور</label>
                <input type="password" name="password" placeholder="رمز عبور را وارد کنید" required>
            </div>
            <button type="submit" class="btn">ورود به پنل</button>
        </form>
    </div>
</body>
</html>'''

DASHBOARD_HTML = '''<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد - Lichess Bot</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, sans-serif; }
        body { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%); min-height: 100vh; color: #fff; }
        .header { background: rgba(255, 255, 255, 0.1); padding: 20px 40px; display: flex; justify-content: space-between; align-items: center; backdrop-filter: blur(10px); }
        .header h1 { font-size: 24px; display: flex; align-items: center; gap: 10px; }
        .logout-btn { background: rgba(255, 82, 82, 0.3); color: #fff; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; text-decoration: none; transition: all 0.3s; }
        .logout-btn:hover { background: rgba(255, 82, 82, 0.5); }
        .container { max-width: 1000px; margin: 40px auto; padding: 0 20px; }
        .status-card { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border-radius: 20px; padding: 30px; margin-bottom: 30px; border: 1px solid rgba(255, 255, 255, 0.1); }
        .status-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 15px; }
        .status-indicator { display: flex; align-items: center; gap: 10px; }
        .status-dot { width: 15px; height: 15px; border-radius: 50%; animation: pulse 2s infinite; }
        .status-dot.running { background: #4caf50; box-shadow: 0 0 20px #4caf50; }
        .status-dot.stopped { background: #ff5252; box-shadow: 0 0 20px #ff5252; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.5; } }
        .control-buttons { display: flex; gap: 15px; }
        .btn { padding: 15px 30px; border: none; border-radius: 10px; font-size: 16px; font-weight: bold; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; gap: 8px; }
        .btn-start { background: linear-gradient(135deg, #4caf50 0%, #45a049 100%); color: #fff; }
        .btn-start:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(76, 175, 80, 0.4); }
        .btn-stop { background: linear-gradient(135deg, #ff5252 0%, #f44336 100%); color: #fff; }
        .btn-stop:hover { transform: translateY(-2px); box-shadow: 0 10px 20px rgba(255, 82, 82, 0.4); }
        .btn:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }
        .logs-container { background: rgba(0, 0, 0, 0.3); border-radius: 15px; padding: 20px; height: 300px; overflow-y: auto; font-family: 'Courier New', monospace; font-size: 13px; }
        .log-line { padding: 5px 0; border-bottom: 1px solid rgba(255, 255, 255, 0.05); color: rgba(255, 255, 255, 0.8); }
        .info-cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }
        .info-card { background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); border-radius: 15px; padding: 20px; text-align: center; border: 1px solid rgba(255, 255, 255, 0.1); }
        .info-card h3 { font-size: 14px; color: rgba(255, 255, 255, 0.7); margin-bottom: 10px; }
        .info-card p { font-size: 24px; font-weight: bold; color: #667eea; }
        .section-title { font-size: 18px; margin-bottom: 15px; color: rgba(255, 255, 255, 0.9); }
    </style>
</head>
<body>
    <div class="header">
        <h1>♞ پنل مدیریت Lichess Bot</h1>
        <a href="/logout" class="logout-btn">خروج</a>
    </div>
    <div class="container">
        <div class="info-cards">
            <div class="info-card"><h3>نوع بازی</h3><p>Bullet</p></div>
            <div class="info-card"><h3>زمان</h3><p>1-2 دقیقه</p></div>
            <div class="info-card"><h3>موتور</h3><p>Stockfish 17</p></div>
            <div class="info-card"><h3>قدرت</h3><p>~3100 Elo</p></div>
        </div>
        <div class="status-card">
            <div class="status-header">
                <div class="status-indicator">
                    <div class="status-dot" id="statusDot"></div>
                    <span id="statusText">در حال بررسی...</span>
                </div>
                <div class="control-buttons">
                    <button class="btn btn-start" id="startBtn" onclick="startBot()">▶ شروع ربات</button>
                    <button class="btn btn-stop" id="stopBtn" onclick="stopBot()">■ توقف ربات</button>
                </div>
            </div>
            <h3 class="section-title">لاگ‌های ربات</h3>
            <div class="logs-container" id="logsContainer">
                <div class="log-line">در انتظار شروع ربات...</div>
            </div>
        </div>
    </div>
    <script>
        function updateStatus() {
            fetch('/bot_status').then(r => r.json()).then(data => {
                document.getElementById('statusDot').className = 'status-dot ' + (data.running ? 'running' : 'stopped');
                document.getElementById('statusText').textContent = data.running ? 'ربات در حال اجرا است' : 'ربات متوقف است';
                document.getElementById('startBtn').disabled = data.running;
                document.getElementById('stopBtn').disabled = !data.running;
                if (data.logs && data.logs.length > 0) {
                    document.getElementById('logsContainer').innerHTML = data.logs.map(log => '<div class="log-line">' + log + '</div>').join('');
                    document.getElementById('logsContainer').scrollTop = document.getElementById('logsContainer').scrollHeight;
                }
            });
        }
        function startBot() { fetch('/start_bot', {method: 'POST'}).then(() => updateStatus()); }
        function stopBot() { fetch('/stop_bot', {method: 'POST'}).then(() => updateStatus()); }
        setInterval(updateStatus, 2000);
        updateStatus();
    </script>
</body>
</html>'''

@app.route('/')
def index():
    session = get_session()
    if session.get('logged_in'):
        return redirect('/dashboard')
    return redirect('/login')

@app.route('/login', method=['GET', 'POST'])
def login():
    error = ""
    if request.method == 'POST':
        username = request.forms.get('username')
        password = request.forms.get('password')
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            set_session({'logged_in': True})
            return redirect('/dashboard')
        else:
            error = '<div class="error">نام کاربری یا رمز اشتباه است</div>'
    return LOGIN_HTML.replace('{{error}}', error)

@app.route('/dashboard')
def dashboard():
    session = get_session()
    if not session.get('logged_in'):
        return redirect('/login')
    return DASHBOARD_HTML

@app.route('/start_bot', method='POST')
def start_bot():
    global bot_process, bot_running
    session = get_session()
    if not session.get('logged_in'):
        response.content_type = 'application/json'
        return json.dumps({'success': False, 'message': 'Not authorized'})
    
    if not bot_running:
        thread = threading.Thread(target=run_bot, daemon=True)
        thread.start()
        response.content_type = 'application/json'
        return json.dumps({'success': True, 'message': 'Bot started'})
    response.content_type = 'application/json'
    return json.dumps({'success': False, 'message': 'Bot already running'})

@app.route('/stop_bot', method='POST')
def stop_bot():
    global bot_process, bot_running
    session = get_session()
    if not session.get('logged_in'):
        response.content_type = 'application/json'
        return json.dumps({'success': False, 'message': 'Not authorized'})
    
    if bot_process and bot_running:
        bot_process.terminate()
        bot_process = None
        bot_running = False
        response.content_type = 'application/json'
        return json.dumps({'success': True, 'message': 'Bot stopped'})
    response.content_type = 'application/json'
    return json.dumps({'success': False, 'message': 'Bot not running'})

@app.route('/bot_status')
def bot_status():
    session = get_session()
    response.content_type = 'application/json'
    if not session.get('logged_in'):
        return json.dumps({'running': False, 'logs': []})
    return json.dumps({'running': bot_running, 'logs': bot_log[-20:]})

@app.route('/logout')
def logout():
    session_id = request.get_cookie("session_id")
    if session_id and session_id in sessions:
        del sessions[session_id]
    response.delete_cookie("session_id")
    redirect('/login')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)

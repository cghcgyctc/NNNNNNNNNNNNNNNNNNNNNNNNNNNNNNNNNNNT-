# Lichess Bot Project

## Overview
Lichess chess bot with Stockfish 17 engine and web-based admin interface using Bottle framework.

## Current State
✅ **Fully Configured**
- Stockfish 17 chess engine (~3100 Elo)
- Bullet games only (1-2 minutes)
- 100ms per move (ultra-fast)
- Auto-challenge other bots every 3 minutes
- Persian web admin interface (Bottle)

## Project Architecture
- **bottle_app.py** - Web admin interface (Bottle framework)
- **lichess-bot.py** - Bot entry point
- **config.yml** - Bot configuration
- **lib/** - Core bot logic
- **homemade.py** - Custom engines

## Login Credentials
- **Username**: 44
- **Password**: 88877aA

## PythonAnywhere Deployment
1. Upload all files to PythonAnywhere
2. Create new web app with Bottle
3. Point to bottle_app.py
4. Set LICHESS_BOT_TOKEN environment variable

## Recent Changes
- **2025-12-05**: Converted from web2py to Bottle for simpler deployment
  - Persian admin interface with start/stop controls
  - Live log viewing
  - Session-based authentication